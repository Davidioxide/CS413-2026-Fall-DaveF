"""Optional unittest reference. The main lab examples use pytest."""
import unittest
import model


class TestModel(unittest.TestCase):
    def setUp(self):
        model.tasks.clear()
        self.addCleanup(model.tasks.clear)

    def test_trims_title(self):
        error = model.add_task(" Read Chapter 5 ")
        self.assertIsNone(error)
        self.assertEqual(model.tasks, ["Read Chapter 5"])


class TestWeb(unittest.TestCase):
    def setUp(self):
        from controller import app
        model.tasks.clear()
        self.addCleanup(model.tasks.clear)
        old_testing = app.config["TESTING"]
        self.addCleanup(app.config.update, TESTING=old_testing)
        app.config["TESTING"] = True
        self.client = app.test_client()

    def test_submit_task(self):
        response = self.client.post("/", data={"title": " Read Chapter 5 "})
        self.assertEqual(response.status_code, 303)
        self.assertEqual(response.headers["Location"], "/")
        self.assertEqual(model.tasks, ["Read Chapter 5"])
        page = self.client.get("/")
        self.assertEqual(page.status_code, 200)
        self.assertIn("<li>Read Chapter 5</li>", page.get_data(as_text=True))


if __name__ == "__main__":
    unittest.main()
