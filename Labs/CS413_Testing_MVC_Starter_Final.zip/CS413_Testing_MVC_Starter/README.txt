CS413 - TESTING IN PYTHON
STUDENT STARTER
The application is complete. Implement the test TODOs shown below.
Unfinished TODOs are marked SKIPPED when tests run.

SETUP - PYTHON 3.10+
Open a terminal in the folder containing app.py.

macOS / Linux:
  python3 -m venv .venv
  source .venv/bin/activate
  python -m pip install -r requirements.txt

Windows Command Prompt:
  py -3 -m venv .venv
  .venv\Scripts\activate.bat
  python -m pip install -r requirements.txt

Windows PowerShell, without activating the environment:
  py -3 -m venv .venv
  .venv\Scripts\python.exe -m pip install -r requirements.txt
Use .venv\Scripts\python.exe in place of python in the remaining commands.

TEST FILES AND SLIDES - CS413_Testing_MVC_Revised.pptx
  TODO 1  tests/unit/test_model.py          slide 10
  TODO 2  tests/unit/test_controller.py     slides 16-20; complete code on slide 21
  TODO 3  tests/integration/test_web.py     slide 25
  TODO 4  tests/integration/test_web.py     slide 26
  TODO 5  tests/e2e/test_browser.py         slide 29
Shared fixtures are in tests/conftest.py (slides 9 and 24).
The Controller source is introduced on slides 13-14. Slide 15 explains
what the Controller unit test checks. Slides 16-20 explain the same test; slide 21 shows the complete function.

WHERE THE CONTROLLER-TEST NAMES COME FROM
  controller                controller.py (a Python module, not an installed package).
  controller.app            app object created in controller.py.
  controller.index()        Function defined in controller.py; the unit-test target.
  test_request_context()    Method on that app object (dependency: flask).
                            Supplies request.method and request.form; does not call index.
  monkeypatch               Built-in pytest fixture requested by the test parameter.
  monkeypatch.setattr()     Installs a replacement and restores the original after the test.
  fake_add / fake_render    Replacement functions defined in tests/unit/test_controller.py.
  add_calls / render_calls  Lists written by fake_add/fake_render, then read by the test assertions.

TEST SEQUENCE (one function)
  Slide 16: define fake_add and install it in place of model.add_task.
  Slide 17: define fake_render and install it in place of render_template.
  Slide 18: supply request.method and request.form, then call controller.index().
  Slide 19: see how the single index() call fills the recording lists; no code to paste.
  Slide 20: read the lists in assertions and check the returned value.
  Slide 21: complete test in two columns, continuing the same function.
  Slide 22: begin integration testing.

fake_add records each title in add_calls and returns "Enter a task.".
fake_render saves a dictionary of arguments in render_calls and returns "page".
The real validation and template rendering do not run in this unit test.
The test checks that index() forwards the error and returns the renderer's result.
The later integration tests run the real components together.

The real template is shown on slide 23 before integration checks inspect HTML.
Slide 29 shows TODO 5 as a browser-test example with a Playwright documentation link.
The optional unittest code is visible on slide 33.

RUN TESTS
  python -m pytest -v tests/unit
  python -m pytest -v tests/integration
  python -m pytest -v
The last command runs the unit and integration folders in pytest.ini.
Test files and functions use the test_ prefix. -v lists each case.
Select one function with path/to/test_file.py::test_function_name.

BROWSER INSTALLATION
  python -m pip install -r requirements-browser.txt
  python -m playwright install chromium
On supported Linux systems that need browser libraries:
  python -m playwright install --with-deps chromium

RUN BROWSER TESTS
  python -m pytest -v tests/e2e
  python -m pytest -v tests/e2e --headed
The page fixture comes from pytest-playwright. live_url, defined in
 tests/e2e/conftest.py, starts and stops a local test server for each test.
Do not start python app.py for these tests. --headed opens a visible window
and needs a graphical desktop. Run this in-memory example serially.
Blank-input and refresh checks are supplied as additional browser tests.

FAILURE EXAMPLES
Use the Solution or complete the Starter TODOs first.
  python demo_failure.py unit
  python demo_failure.py integration
  python demo_failure.py e2e
Each command creates a temporary copy, introduces one defect, runs tests,
and removes the copy. The working application is not edited.

unit:        The Model omits strip(). The trimming assertion fails.
integration: The View omits its error block. The real-HTML check fails.
e2e:         The form sends task, while the Controller expects title.
             The browser test fails to find the newly submitted task.
The helper exits successfully only when the expected test outcomes occur.

OPEN THE APPLICATION MANUALLY
  python app.py
Visit http://127.0.0.1:5000/ in a browser. Ctrl+C stops the server.
The application keeps a shared list in memory, allows repeated titles,
and clears the list on server restart. It is a local classroom example,
not a deployment-ready service. It has no login, database, per-user
isolation, or CSRF protection. Keep the server local.

TROUBLESHOOTING
No module named flask/pytest: use the environment where dependencies were installed.
Fixture page not found: install requirements-browser.txt in that environment.
Browser executable missing: run python -m playwright install chromium.
No module named model: run from the folder containing app.py and model.py.
A SKIPPED starter TODO has not checked the required behavior yet.

VERIFICATION
See VERIFICATION.txt for the checks executed during preparation and limits.
After installing dependencies, run the completed examples locally with:
  python verify_lab.py --browser

OPTIONAL UNITTEST REFERENCE
  python -m unittest -v unittest_alt.test_examples
These alternatives are not part of the main pytest walkthrough.
The web test needs Flask. Run only the Model test without Flask:
  python -m unittest -v unittest_alt.test_examples.TestModel

DOCUMENTATION
https://playwright.dev/python/docs/intro
https://docs.pytest.org/en/stable/getting-started.html
https://docs.pytest.org/en/stable/how-to/fixtures.html
https://docs.pytest.org/en/stable/how-to/parametrize.html
https://docs.python.org/3/library/unittest.html
https://docs.pytest.org/en/stable/how-to/monkeypatch.html
https://flask.palletsprojects.com/en/stable/testing/
https://playwright.dev/python/docs/writing-tests
https://playwright.dev/python/docs/test-runners
https://flask.palletsprojects.com/en/stable/quickstart/
