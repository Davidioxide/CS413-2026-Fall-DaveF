"""Browser tests for task entry, blank-input rejection, and page refresh.

The page fixture comes from pytest-playwright. live_url comes from conftest.py.
Only the fixture accesses app internals: each test body interacts as a user.
"""
import pytest
from playwright.sync_api import expect


def test_add_task_in_browser(page, live_url):
    # TODO 5: complete the test using slide 29.
    pytest.skip("TODO 5: test not implemented yet")


# Supplied browser check for blank input and existing data.
def test_blank_submission_keeps_existing_task(page, live_url):
    # Add an existing task through the form.
    page.goto(live_url)
    page.get_by_label("Task title").fill("Read Chapter 5")
    page.get_by_role("button", name="Add task").click()
    expect(page.get_by_role("listitem")).to_have_text(["Read Chapter 5"])

    # WHEN the user submits only spaces.
    page.get_by_label("Task title").fill("   ")
    page.get_by_role("button", name="Add task").click()

    # THEN the error is visible and the existing task is still the only task.
    expect(page.get_by_role("alert")).to_have_text("Enter a task.")
    expect(page.get_by_role("listitem")).to_have_text(["Read Chapter 5"])


def test_refresh_keeps_one_copy(page, live_url):
    # Refreshing the result page must not add the task a second time.
    page.goto(live_url)
    page.get_by_label("Task title").fill("Read Chapter 5")
    page.get_by_role("button", name="Add task").click()
    expect(page.get_by_role("listitem")).to_have_text(["Read Chapter 5"])
    page.reload()
    expect(page.get_by_role("listitem")).to_have_text(["Read Chapter 5"])
