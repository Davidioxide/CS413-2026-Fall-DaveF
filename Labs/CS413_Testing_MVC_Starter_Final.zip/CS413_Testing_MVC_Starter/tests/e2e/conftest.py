"""Start a temporary LOCAL server for each browser test; no manual server needed.

The app stores data in a global Python list. Run these classroom tests serially.
The server uses the same process so empty_tasks can reset the real server state.
The server shuts down before that fixture performs its final cleanup.
"""
from threading import Thread
import pytest


@pytest.fixture
def live_url(app, empty_tasks):
    from werkzeug.serving import make_server
    server = make_server("127.0.0.1", 0, app, threaded=True)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_port}"
    finally:
        server.shutdown()
        thread.join(timeout=5)
        server.server_close()
        if thread.is_alive():
            raise RuntimeError("The classroom test server did not shut down.")
