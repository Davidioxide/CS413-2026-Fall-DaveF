"""Unit tests: the real Model, with no Controller, template or browser."""
import pytest
import model


def test_trims_title():
    # TODO 1: complete the test using slide(s) 10.
    pytest.skip("TODO 1: test not implemented yet")


@pytest.mark.parametrize(
    "title", ["", "   ", "\t"]
)
def test_rejects_blank_title(title):
    model.tasks.append("Read Chapter 5")
    error = model.add_task(title)
    assert error == "Enter a task."
    assert model.tasks == ["Read Chapter 5"]
