"""Unit tests for index() in controller.py.

Target: controller.index stays unchanged.
Replacements installed by pytest's monkeypatch fixture:
    controller.model.add_task -> fake_add
    controller.render_template -> fake_render

fake_add/fake_render and the two recording lists are defined in this test file.
app.test_request_context is an application-object method from the flask dependency.
"""

import pytest      # dependency: pytest
import controller  # controller.py


def test_passes_error_to_view(monkeypatch):
    # TODO 2: follow slides 16-20; the complete test is on slide 21.
    # 13-14: controller.py imports, app object, and index() source.
    # 15: index() is unchanged; add_task -> fake_add, renderer -> fake_render.
    # 16: define fake_add, record titles, and install the first replacement.
    # 17: define fake_render, record arguments, and install the second.
    # 18: supply POST data and call controller.index().
    # 19: trace that call; this page contains no extra test code to paste.
    # 20: read add_calls and render_calls in assertions; check the returned result.
    # 21: complete function; read the left column, then the right.
    pytest.skip("TODO 2: test not implemented yet")


def test_success_redirects_instead_of_rendering(monkeypatch):
    add_calls = []
    render_calls = []

    def fake_add(title):
        add_calls.append(title)
        return None

    def fake_render(template, tasks, error, title):
        render_calls.append({
            "template": template,
            "tasks": tasks.copy(),
            "error": error,
            "title": title,
        })
        return "page"

    monkeypatch.setattr(controller.model, "add_task", fake_add)
    monkeypatch.setattr(controller, "render_template", fake_render)
    with controller.app.test_request_context(
        "/", method="POST", data={"title": "Read Chapter 5"}
    ):
        response = controller.index()

    assert add_calls == ["Read Chapter 5"]
    assert render_calls == []
    assert response.status_code == 303
    assert response.headers["Location"] == "/"


def test_get_does_not_add_a_task(monkeypatch):
    add_calls = []
    render_calls = []

    def fake_add(title):
        add_calls.append(title)
        return None

    def fake_render(template, tasks, error, title):
        render_calls.append({
            "template": template,
            "tasks": tasks.copy(),
            "error": error,
            "title": title,
        })
        return "page"

    monkeypatch.setattr(controller.model, "add_task", fake_add)
    monkeypatch.setattr(controller, "render_template", fake_render)
    with controller.app.test_request_context("/", method="GET"):
        result = controller.index()

    assert add_calls == []
    assert render_calls == [{
        "template": "tasks.html",
        "tasks": [],
        "error": None,
        "title": "",
    }]
    assert result == "page"
