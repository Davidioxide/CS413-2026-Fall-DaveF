"""Pytest fixtures, shared by the tests below this folder.

empty_tasks: resets the existing list from model.py for each test.
app: supplies the existing Flask object from controller.py, not a new app.
client: returns Flask's test client. Tests request it with a client parameter.
The monkeypatch fixture is supplied by pytest itself, not defined here.
"""
import pytest
import model


@pytest.fixture(autouse=True)
def empty_tasks():
    model.tasks.clear()  # Set up an empty list before the test.
    yield                # Pause here; pytest runs the test function.
    model.tasks.clear()  # Resume after the test and clean up its data.


@pytest.fixture
def app():
    from controller import app as application
    previous = application.config["TESTING"]
    application.config["TESTING"] = True
    yield application  # Supply the app; pause until the test finishes.
    application.config["TESTING"] = previous


@pytest.fixture
def client(app):
    return app.test_client()
