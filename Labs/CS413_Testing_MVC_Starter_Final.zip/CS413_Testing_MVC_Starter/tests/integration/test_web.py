"""Integration tests: real routing, Controller, Model and Jinja View.

The Flask test client constructs form requests and checks the response and
stored data. Browser interaction tests are in tests/e2e/test_browser.py.
"""
import pytest
import model


def test_open_empty_page(client):
    response = client.get("/")
    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert '<form method="post" action="/">' in html
    assert "No tasks yet." in html


def test_submit_task(client):
    # TODO 3: complete the test using slide 25.
    pytest.skip("TODO 3: test not implemented yet")


def test_rejected_post_preserves_tasks(client):
    # TODO 4: complete the test using slide 26.
    pytest.skip("TODO 4: test not implemented yet")


def test_missing_title_field_is_rejected(client):
    response = client.post("/", data={})
    assert "Enter a task." in response.get_data(as_text=True)
    assert model.tasks == []


def test_refresh_does_not_resubmit(client):
    client.post("/", data={"title": "Read Chapter 5"}, follow_redirects=True)
    client.get("/")
    assert model.tasks == ["Read Chapter 5"]


def test_html_title_is_rendered_as_text(client):
    response = client.post("/", data={"title": "<b>Task</b>"}, follow_redirects=True)
    html = response.get_data(as_text=True)
    assert "&lt;b&gt;Task&lt;/b&gt;" in html
    assert "<li><b>Task</b></li>" not in html


def test_success_clears_previous_error(client):
    client.post("/", data={"title": "   "})
    response = client.post("/", data={"title": "Prepare lab notes"}, follow_redirects=True)
    html = response.get_data(as_text=True)
    assert "Enter a task." not in html
    assert "<li>Prepare lab notes</li>" in html
