"""Start the local classroom demo: python app.py."""

from controller import app

if __name__ == "__main__":
    # This development server is for local teaching, not public deployment.
    # Restart it after editing Python files; restarting clears the task list.
    app.run(host="127.0.0.1", port=5000, debug=False)
