"""Model: task data and the rule for accepting a task title."""

tasks: list[str] = []


def add_task(title: str) -> str | None:
    """Return an error message, or None when the task is accepted."""
    cleaned = title.strip()
    if cleaned == "":
        return "Enter a task."
    tasks.append(cleaned)
    return None
