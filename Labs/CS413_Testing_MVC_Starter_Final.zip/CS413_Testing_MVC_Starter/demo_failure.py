"""Demonstrate one defect in a TEMPORARY copy, never in your working application.

Usage: python demo_failure.py unit|integration|e2e
A successful demonstration exits 0 AFTER observing an intentional test failure.
Exit 2 means setup or an expected pass/fail result was not as intended.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parent


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("level", choices=["unit", "integration", "e2e"])
    args = parser.parse_args()
    with TemporaryDirectory(prefix="cs413_mvc_demo_") as tmp:
        work = Path(tmp)
        for name in ["model.py", "controller.py", "app.py", "pytest.ini"]:
            shutil.copy2(ROOT / name, work / name)
        for name in ["templates", "static", "tests"]:
            shutil.copytree(ROOT / name, work / name,
                            ignore=shutil.ignore_patterns("__pycache__", ".pytest_cache"))
        if args.level == "unit":
            target = work / "model.py"
            old, new = "cleaned = title.strip()", "cleaned = title"
            before = []
            failing = ["tests/unit/test_model.py::test_trims_title"]
            description = "Model: surrounding whitespace is no longer removed."
        elif args.level == "integration":
            target = work / "templates/tasks.html"
            old = '    {% if error %}\n      <p class="error" role="alert">{{ error }}</p>\n    {% endif %}'
            new = '    <!-- Intentional demo defect: the error block is missing. -->'
            before = ["tests/unit"]
            failing = ["tests/integration/test_web.py::test_rejected_post_preserves_tasks"]
            description = "View: the template no longer displays the supplied error."
        else:
            target = work / "templates/tasks.html"
            old, new = 'name="title"', 'name="task"'
            before = ["tests/unit", "tests/integration"]
            failing = ["tests/e2e/test_browser.py::test_add_task_in_browser"]
            description = "Form: input name is task, but the Controller reads title."
        text = target.read_text(encoding="utf-8")
        if text.count(old) != 1:
            print("Cannot apply the example: expected source block is missing or duplicated.")
            return 2
        target.write_text(text.replace(old, new, 1), encoding="utf-8")
        print(f"\nDEMO: {description}\nWorking files are unchanged.\n", flush=True)
        if before:
            print("First run the earlier-scope checks; these should pass:", flush=True)
            result = subprocess.run([sys.executable, "-m", "pytest", "-q", *before], cwd=work)
            if result.returncode != 0:
                print("Earlier checks did not pass. Check dependencies or finish the starter TODOs.")
                return 2
        print("\nNow run the check that should expose the defect:", flush=True)
        result = subprocess.run([sys.executable, "-m", "pytest", "-v", "--tb=short", *failing], cwd=work)
        if result.returncode == 1:
            print("\nExpected test failure observed. Your working application was not edited.")
            return 0
        print("Expected a test failure (pytest exit 1); inspect setup and test completeness.")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
