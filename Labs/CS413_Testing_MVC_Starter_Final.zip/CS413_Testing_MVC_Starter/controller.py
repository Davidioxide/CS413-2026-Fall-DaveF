"""Controller: handle the browser's request, call the model, select a response."""

from flask import Flask, redirect, render_template, request
import model

app = Flask(__name__)


@app.route("/", methods=["GET", "POST"])
def index():
    error = None
    title = ""
    if request.method == "POST":
        title = request.form.get("title", "")
        error = model.add_task(title)
        if error is None:
            return redirect("/", code=303)
    return render_template(
        "tasks.html", tasks=model.tasks,
        error=error, title=title
    )
