"""Run the full lab checks locally after installing the documented dependencies.

python verify_lab.py           # pytest unit + integration and defect demos
python verify_lab.py --browser # also browser/system tests and all defect demos
python verify_lab.py --unittest-reference # also the optional unittest examples
"""
import argparse
import subprocess
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--browser", action="store_true")
    parser.add_argument("--unittest-reference", action="store_true",
                        help="also check the optional unittest reference")
    args = parser.parse_args()
    commands = [
        ["-m", "pytest", "-v", "tests/unit", "tests/integration"],
        ["demo_failure.py", "unit"],
        ["demo_failure.py", "integration"],
    ]
    if args.unittest_reference:
        commands.append(["-m", "unittest", "-v", "unittest_alt.test_examples"])
    if args.browser:
        commands.extend([
            ["-m", "pytest", "-v", "tests/e2e"],
            ["demo_failure.py", "e2e"],
        ])
    root = Path(__file__).resolve().parent
    for command in commands:
        print("\n$ python " + " ".join(command), flush=True)
        result = subprocess.run([sys.executable, *command], cwd=root)
        if result.returncode:
            return result.returncode
    print("\nAll requested checks completed with their expected outcomes.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
